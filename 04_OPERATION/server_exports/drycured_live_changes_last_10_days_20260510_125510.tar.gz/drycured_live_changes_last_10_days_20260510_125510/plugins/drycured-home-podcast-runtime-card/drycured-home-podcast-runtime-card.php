<?php
/**
 * Plugin Name: Drycured Home Podcast Runtime Card
 * Description: Na home stranici zamjenjuje staru karticu recepta podcast karticom, bez diranja kalkulatora i infografike.
 * Version: 1.1.0
 * Author: drycured.com
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_footer', function () {
    $page = get_page_by_path('podcast/osnove-dobrog-suhomesnatog-proizvoda');
    if (!$page) {
        $page = get_page_by_path('osnove-dobrog-suhomesnatog-proizvoda');
    }

    $url = $page ? get_permalink($page) : '/podcast/osnove-dobrog-suhomesnatog-proizvoda/';
    $title = $page ? get_the_title($page) : 'Epizoda 1: Osnove dobrog suhomesnatog proizvoda';

    $excerpt = $page ? get_post_meta($page->ID, '_dc_podcast_excerpt', true) : '';
    if (!$excerpt) {
        $excerpt = 'Prva epizoda Drycured podcasta govori o temelju svake dobre šarže: mesu, soli, redoslijedu procesa i strpljenju koje se ne može preskočiti.';
    }

    $image = $page ? get_the_post_thumbnail_url($page->ID, 'large') : '';
    if (!$image) {
        $image = 'https://drycured.com/wp-content/uploads/2026/05/drycured_podcast_ep01-1024x683.png';
    }
    ?>
    <script id="drycured-home-podcast-runtime-card">
    (function () {
        const data = {
            oldTitle: 'Recept za domaću kobasicu bez slike',
            oldSlug: 'recept-za-domacu-kobasicu-bez-slike',
            title: <?php echo wp_json_encode($title, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>,
            excerpt: <?php echo wp_json_encode($excerpt, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>,
            url: <?php echo wp_json_encode($url, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>,
            image: <?php echo wp_json_encode($image, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>
        };

        function norm(t) {
            return (t || '')
                .normalize('NFD')
                .replace(/[\u0300-\u036f]/g, '')
                .replace(/\s+/g, ' ')
                .trim()
                .toLowerCase();
        }

        function esc(t) {
            const d = document.createElement('div');
            d.textContent = t || '';
            return d.innerHTML;
        }

        function replaceSectionTitle() {
            document.querySelectorAll('h1,h2,h3,h4,.elementor-heading-title').forEach(function (h) {
                if (norm(h.textContent) === 'najnoviji clanci') {
                    h.textContent = 'Najnoviji sadržaj';
                }
            });
        }

        function restoreInfographicCard() {
            document.querySelectorAll('[data-dc-hidden-old-recipe], div, article, section').forEach(function (el) {
                const t = norm(el.innerText || '');
                if (
                    t.includes('infografika dana') ||
                    t.includes('vrste masnog tkiva')
                ) {
                    el.style.display = '';
                    el.removeAttribute('data-dc-hidden-old-recipe');
                }
            });
        }

        function buildPodcastCard() {
            return `
                <article class="dc-runtime-podcast-card">
                    <a class="dc-runtime-podcast-image-link" href="${esc(data.url)}">
                        <img class="dc-runtime-podcast-image" src="${esc(data.image)}" alt="${esc(data.title)}" loading="lazy">
                    </a>

                    <div class="dc-runtime-podcast-label">Novi podcast</div>

                    <h3 class="dc-runtime-podcast-title">
                        <a href="${esc(data.url)}">${esc(data.title)}</a>
                    </h3>

                    <p class="dc-runtime-podcast-excerpt">${esc(data.excerpt)}</p>

                    <a class="dc-runtime-podcast-link" href="${esc(data.url)}">Slušaj epizodu →</a>
                </article>
            `;
        }

        function findOldRecipeLinks() {
            return Array.from(document.querySelectorAll('a')).filter(function (a) {
                const txt = norm(a.textContent || '');
                const href = norm(a.getAttribute('href') || '');
                return txt.includes(norm(data.oldTitle)) || href.includes(data.oldSlug);
            });
        }

        function removeOldRecipeFragments() {
            findOldRecipeLinks().forEach(function (a) {
                let node = a;
                let target = null;

                for (let i = 0; i < 10 && node && node !== document.body; i++) {
                    const t = norm(node.innerText || '');
                    const protectedBlock =
                        t.includes('kalkulator novosti') ||
                        t.includes('infografika dana') ||
                        t.includes('vrste masnog tkiva') ||
                        t.includes('novi podcast') ||
                        t.includes('epizoda 1');

                    if (protectedBlock) {
                        break;
                    }

                    if (
                        t.includes(norm(data.oldTitle)) ||
                        (node.innerHTML || '').includes(data.oldSlug) ||
                        node.querySelector('img')
                    ) {
                        target = node;
                    }

                    node = node.parentElement;
                }

                if (target) {
                    target.remove();
                } else {
                    a.remove();
                }
            });
        }

        function insertPodcastIfMissing() {
            if (document.querySelector('.dc-runtime-podcast-card')) {
                return;
            }

            // Pokušaj umetnuti podcast na mjesto stare recept-kartice.
            const oldLinks = findOldRecipeLinks();

            if (oldLinks.length) {
                const a = oldLinks[0];
                let node = a;
                let target = null;

                for (let i = 0; i < 10 && node && node !== document.body; i++) {
                    const t = norm(node.innerText || '');
                    const protectedBlock =
                        t.includes('kalkulator novosti') ||
                        t.includes('infografika dana') ||
                        t.includes('vrste masnog tkiva');

                    if (protectedBlock) {
                        break;
                    }

                    if (
                        t.includes(norm(data.oldTitle)) &&
                        (node.querySelector('img') || t.includes('read more') || t.includes('nema komentara'))
                    ) {
                        target = node;
                    }

                    node = node.parentElement;
                }

                if (target) {
                    target.innerHTML = buildPodcastCard();
                    return;
                }
            }

            // Ako je stara kartica već uklonjena, umetni podcast ispred infografike.
            const infoNode = Array.from(document.querySelectorAll('div, article, section')).find(function (el) {
                const t = norm(el.innerText || '');
                return t.includes('infografika dana') && t.includes('vrste masnog tkiva');
            });

            if (infoNode && infoNode.parentElement) {
                const wrapper = document.createElement('div');
                wrapper.innerHTML = buildPodcastCard();
                infoNode.parentElement.insertBefore(wrapper.firstElementChild, infoNode);
            }
        }

        function run() {
            replaceSectionTitle();
            restoreInfographicCard();
            insertPodcastIfMissing();
            removeOldRecipeFragments();
            restoreInfographicCard();
        }

        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', run);
        } else {
            run();
        }

        window.addEventListener('load', run);

        let tries = 0;
        const timer = setInterval(function () {
            tries++;
            run();
            if (tries > 12) {
                clearInterval(timer);
            }
        }, 600);
    })();
    </script>
    <?php
}, 999999);

add_action('wp_head', function () {
    ?>
    <style id="drycured-home-podcast-runtime-card-style">
        .dc-runtime-podcast-card {
            width: 100%;
        }

        .dc-runtime-podcast-image-link {
            display: block;
            width: 100%;
            margin-bottom: 18px;
            overflow: hidden;
            text-decoration: none !important;
        }

        .dc-runtime-podcast-image {
            display: block;
            width: 100%;
            height: 210px;
            object-fit: cover;
            object-position: center center;
        }

        .dc-runtime-podcast-label {
            margin-bottom: 8px;
            font-size: 11px;
            line-height: 1.2;
            letter-spacing: .14em;
            text-transform: uppercase;
            color: #d39a3a;
            font-weight: 800;
        }

        .dc-runtime-podcast-title {
            margin: 0 0 10px 0;
            font-size: 18px !important;
            line-height: 1.3 !important;
            font-weight: 600 !important;
        }

        .dc-runtime-podcast-title a {
            color: #1f2530 !important;
            text-decoration: none !important;
        }

        .dc-runtime-podcast-title a:hover {
            color: #d39a3a !important;
            text-decoration: underline !important;
        }

        .dc-runtime-podcast-excerpt {
            margin: 0 0 14px 0;
            font-size: 14px !important;
            line-height: 1.55 !important;
            color: #555f68 !important;
        }

        .dc-runtime-podcast-link {
            display: inline-flex;
            align-items: center;
            font-size: 12px !important;
            font-weight: 800 !important;
            letter-spacing: .05em;
            text-transform: uppercase;
            color: #d39a3a !important;
            text-decoration: none !important;
        }

        .dc-runtime-podcast-link:hover {
            text-decoration: underline !important;
        }
    </style>
    <?php
}, 999999);
